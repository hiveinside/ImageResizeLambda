/**
 * Created by abhijit on 3/3/17.
 */


var feedURL=
    {"feed":[
        "http://minusone.xapi.co.in/api/v1/feeds?lang=en&cats=top"
    ]};


module.exports = feedURL;
